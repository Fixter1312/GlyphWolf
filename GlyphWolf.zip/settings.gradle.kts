rootProject.name = "GlyphWolf"
include(":app")

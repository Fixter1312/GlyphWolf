# GlyphWolf (fixed template)

Minimal Android app that draws a 25x25 wolf and adjusts brightness with battery level.
**Requires** `app/libs/glyph-matrix-sdk-1.0.aar` (minSdk 34).

## How to use
1. Put your AAR into `app/libs/glyph-matrix-sdk-1.0.aar`.
2. Commit & push.
3. GitHub Actions will build the APK (see Actions tab).
